<!DOCTYPE html> <html lang=en> <head> <meta charset=utf-8> <meta content="width=device-width,initial-scale=1" name=viewport> <meta content=#06c name=theme-color> <base href="/"> <link href=manifest.json rel=manifest crossorigin=use-credentials> <link href=/favicon-32x32.png rel=icon sizes=32x32 type=image/png> <link href=/favicon-96x96.png rel=icon sizes=96x96 type=image/png> <link href=/favicon-16x16.png rel=icon sizes=16x16 type=image/png> <link href=/apple-icon-180x180.png rel=apple-touch-icon sizes=180x180> <script async src="https://www.googletagmanager.com/gtag/js?id=UA-205487988-1"></script> <script> window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
  
    gtag('config', 'UA-205487988-1'); </script> <script>__SAPPER__={error:{message:"Not found",name:"PreloadError"},status:404,baseUrl:"",preloaded:[(function(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J){return {headerData:{id:g,locale:h,created_at:"2021-07-19T19:39:34.247Z",updated_at:"2021-07-19T21:42:50.570Z",menu:[{id:g,Label:a,Link:a,label:i,url:j},{id:d,Label:a,Link:a,label:k,url:l},{id:c,Label:a,Link:a,label:m,url:n},{id:e,Label:a,Link:a,label:o,url:p},{id:5,Label:a,Link:a,label:q,url:r},{id:6,Label:a,Link:a,label:s,url:t}],logo:{id:d,name:u,alternativeText:b,caption:b,width:v,height:w,formats:a,hash:x,ext:y,mime:z,size:A,url:B,previewUrl:a,provider:f,provider_metadata:a,created_at:C,updated_at:D},localizations:[{id:d,locale:E},{id:c,locale:F}]},footerData:{id:d,credits:"Copyright © | All rights reserved",locale:h,created_at:"2021-07-20T17:49:48.790Z",updated_at:"2021-08-31T16:26:43.797Z",address:[{id:c,title:"São Paulo",location:"Rua Alves Guimarães, nº 462, Conjunto 21 Pinheiros. CEP: 05.410-000 – São Paulo\u002FSP\nTel.: (11) 4210-2846\nWhatsapp: (11) 97515-8190"},{id:e,title:"Manaus",location:"Av. Ephigênio Salles, nº 126, sala E Parque 10 de Novembro. CEP: 69.055-736 – Manaus\u002FAM\nTel.: (92) 3648-6777 \u002F 3648-6717"}],menu:{id:c,title:"Navigation",links:[{id:11,label:i,url:j},{id:12,label:k,url:l},{id:13,label:m,url:n},{id:14,label:o,url:p},{id:31,label:q,url:r},{id:15,label:s,url:t}]},privacymenu:{id:e,title:"Privacy & Security",links:[{id:16,label:"LGPD",url:"\u002Flgpd"},{id:17,label:"Privacy Policy",url:"\u002Fprivacy-policy"},{id:18,label:"Terms of Use",url:"\u002Fterms-of-service"}]},stores:{id:39,title:"Download the mobile App",imagelink:[{id:77,url:"https:\u002F\u002Fplay.google.com\u002Fstore\u002Fapps\u002Fdetails?id=br.com.sasi.app&hl=pt_BR&gl=US",name:"Google Play",image:{id:c,name:"google_play.jpg",alternativeText:b,caption:b,width:G,height:H,formats:a,hash:"google_play_b15b58071f",ext:I,mime:J,size:2.84,url:"\u002Fuploads\u002Fgoogle_play_b15b58071f.jpg",previewUrl:a,provider:f,provider_metadata:a,created_at:"2021-07-20T02:05:06.299Z",updated_at:"2021-07-20T02:05:06.306Z"}},{id:79,url:"https:\u002F\u002Fapps.apple.com\u002Fbr\u002Fapp\u002Fsasi\u002Fid1467748272",name:"Apple Store",image:{id:e,name:"app_store.jpg",alternativeText:b,caption:b,width:G,height:H,formats:a,hash:"app_store_d57b823520",ext:I,mime:J,size:3.78,url:"\u002Fuploads\u002Fapp_store_d57b823520.jpg",previewUrl:a,provider:f,provider_metadata:a,created_at:"2021-07-20T02:05:06.300Z",updated_at:"2021-07-20T02:05:06.307Z"}}]},socialList:[{id:185,icon:"facebook",url:"https:\u002F\u002Fwww.facebook.com\u002Fsasibrasil"},{id:187,icon:"instagram",url:"https:\u002F\u002Fwww.instagram.com\u002Fsasibrasil\u002F"},{id:190,icon:"linkedin",url:"https:\u002F\u002Fwww.linkedin.com\u002Fcompany\u002Fsasibrasil\u002F"},{id:192,icon:"youtube",url:"https:\u002F\u002Fwww.youtube.com\u002Fchannel\u002FUCqf5-Wco5AwcS4RKgckCwqw"}],logo:{id:d,name:u,alternativeText:b,caption:b,width:v,height:w,formats:a,hash:x,ext:y,mime:z,size:A,url:B,previewUrl:a,provider:f,provider_metadata:a,created_at:C,updated_at:D},localizations:[{id:g,locale:E},{id:c,locale:F}]},apiBaseUrl:"https:\u002F\u002Fnovo-site.sasi.com.br\u002Fapi"}}(null,"",3,2,4,"local",1,"en","Home","\u002F","Platform","\u002Fplatform","Pricing","\u002Fpricing","Security","\u002Fsecurity","Gallery","\u002Fgallery","Contact us","\u002Fcontact","logo-sasi.svg",125,45,"logo_sasi_2438720c75",".svg","image\u002Fsvg+xml",5.64,"\u002Fuploads\u002Flogo_sasi_2438720c75.svg","2021-07-19T21:42:18.951Z","2021-07-19T21:42:18.959Z","pt-BR","es",200,65,".jpg","image\u002Fjpeg")),{}],session:{apiBaseUrl:"https:\u002F\u002Fnovo-site.sasi.com.br\u002Fapi",locale:"en"}};if('serviceWorker' in navigator)navigator.serviceWorker.register('/service-worker.js');(function(){try{eval("async function x(){}");var main="/client/client.56dc2bed.js"}catch(e){main="/client/legacy/client.f5ae221b.js"};var s=document.createElement("script");try{new Function("if(0)import('')")();s.src=main;s.type="module";s.crossOrigin="use-credentials";}catch(e){s.src="/client/shimport@2.0.4.js";s.setAttribute("data-main",main);}document.head.appendChild(s);}());</script> <link rel="stylesheet" href="client/client-06e491bf.css"> <title>404 | Sasi</title><meta name="description" content="SASI is the best platform for application creation, data collection, local monitoring, cloud monitoring, and agile communication" data-svelte="svelte-1evte"> </head> <body> <div id=sapper>



  
  <nav class="main-header svelte-1oki0cw is-page"><div class="container svelte-1oki0cw"><a href="/" class="main-header__logo svelte-1oki0cw"><img src="https://novo-site.sasi.com.br/api/uploads/logo_sasi_2438720c75.svg" alt="Sasi" class="svelte-1oki0cw"></a>

    <div id="main-header__nav" class="svelte-1oki0cw"><button id="btn-mobile" aria-label="Mobile Menu Button" class="svelte-1oki0cw"><span id="hamburger" class="svelte-1oki0cw"></span></button>
      
      <ul class="main-header__menu svelte-1oki0cw" id="main-header__menu"><li id="main-header__menu__links__test" class="svelte-1oki0cw"><a href="/" class=" svelte-1oki0cw">Home</a>
            </li><li id="main-header__menu__links__test" class="svelte-1oki0cw"><a href="/platform" class=" svelte-1oki0cw">Platform</a>
            </li><li id="main-header__menu__links__test" class="svelte-1oki0cw"><a href="/pricing" class=" svelte-1oki0cw">Pricing</a>
            </li><li id="main-header__menu__links__test" class="svelte-1oki0cw"><a href="/security" class=" svelte-1oki0cw">Security</a>
            </li><li id="main-header__menu__links__test" class="svelte-1oki0cw"><a href="/gallery" class=" svelte-1oki0cw">Gallery</a>
            </li><li id="main-header__menu__links__test" class="svelte-1oki0cw"><a href="/contact" class=" svelte-1oki0cw">Contact us</a>
            </li>
      


        <li id="main-header__menu-desktop-flag" class="svelte-1oki0cw"><div class="svelte-1dpmxjb s-select  --small --borderless"><div class="s-select__value svelte-1dpmxjb"><button type="button" title="English" class="svelte-1dpmxjb --imaged"><img src="flag-us.svg" alt="English" class="svelte-1dpmxjb">

      

      </button></div>

  <div class="s-select__options svelte-1dpmxjb"><div class="s-select__options-content svelte-1dpmxjb"><button type="button" class="svelte-1dpmxjb"><img src="flag-pt-br.svg" alt="Português" class="svelte-1dpmxjb">

          <span class="svelte-1dpmxjb">Português</span>
        </button><button type="button" class="svelte-1dpmxjb"><img src="flag-spain.svg" alt="Español" class="svelte-1dpmxjb">

          <span class="svelte-1dpmxjb">Español</span>
        </button></div></div>
</div></li></ul>

      <div id="main-header__menu-mobile-flag" class="svelte-1oki0cw"><div class="svelte-1dpmxjb s-select  --small --borderless"><div class="s-select__value svelte-1dpmxjb"><button type="button" title="English" class="svelte-1dpmxjb --imaged"><img src="flag-us.svg" alt="English" class="svelte-1dpmxjb">

      

      </button></div>

  <div class="s-select__options svelte-1dpmxjb"><div class="s-select__options-content svelte-1dpmxjb"><button type="button" class="svelte-1dpmxjb"><img src="flag-pt-br.svg" alt="Português" class="svelte-1dpmxjb">

          <span class="svelte-1dpmxjb">Português</span>
        </button><button type="button" class="svelte-1dpmxjb"><img src="flag-spain.svg" alt="Español" class="svelte-1dpmxjb">

          <span class="svelte-1dpmxjb">Español</span>
        </button></div></div>
</div></div></div></div>
</nav>
  
  <main>


<main class="s-page svelte-1yx9vgm"><header class="s-page__header svelte-1yx9vgm"><h1 class="svelte-1yx9vgm">Whoops!</h1></header>

  <div class="container">

  <div class="error-container svelte-usua10"><div class="error_img svelte-usua10"><img src="/404.svg" alt="Uma praça vazia"></div>

    <h1 class="error-title svelte-usua10">The page was not found</h1>

    <p class="error-content svelte-usua10">Maybe the address is wrong, or the page may have been removed.</p></div></div>

  

</main></main>

  <footer class="main-footer svelte-a66mxb"><div class="container svelte-a66mxb"><div class="main-footer__logos svelte-a66mxb"><a href="/" class="main-footer__logo svelte-a66mxb"><img src="https://novo-site.sasi.com.br/api/uploads/logo_sasi_2438720c75.svg" alt="SASI" class="svelte-a66mxb"></a>

      
      <ul class="social-list svelte-a66mxb"><li><a href="https://www.facebook.com/sasibrasil" target="_blank" rel="noopener noreferrer" class="svelte-a66mxb"><svg class="svelte-hiexm5 icon"><use xlink:href="feather-sprite.svg#facebook"></use></svg>
                <span class="visible-hidden">facebook</span></a>
            </li><li><a href="https://www.instagram.com/sasibrasil/" target="_blank" rel="noopener noreferrer" class="svelte-a66mxb"><svg class="svelte-hiexm5 icon"><use xlink:href="feather-sprite.svg#instagram"></use></svg>
                <span class="visible-hidden">instagram</span></a>
            </li><li><a href="https://www.linkedin.com/company/sasibrasil/" target="_blank" rel="noopener noreferrer" class="svelte-a66mxb"><svg class="svelte-hiexm5 icon"><use xlink:href="feather-sprite.svg#linkedin"></use></svg>
                <span class="visible-hidden">linkedin</span></a>
            </li><li><a href="https://www.youtube.com/channel/UCqf5-Wco5AwcS4RKgckCwqw" target="_blank" rel="noopener noreferrer" class="svelte-a66mxb"><svg class="svelte-hiexm5 icon"><use xlink:href="feather-sprite.svg#youtube"></use></svg>
                <span class="visible-hidden">youtube</span></a>
            </li></ul>

      <button class="svelte-16i7e3h s-btn    s-btn--secondary-outline"><svg class="svelte-hiexm5 icon"><use xlink:href="feather-sprite.svg#headphones"></use></svg>
        Help Center
</button></div>

    <div><div class="main-footer__address svelte-a66mxb"><h4 class="svelte-a66mxb">São Paulo</h4>
            <p class="svelte-a66mxb">Rua Alves Guimarães, nº 462, Conjunto 21 Pinheiros. CEP: 05.410-000 – São Paulo/SP
Tel.: (11) 4210-2846
Whatsapp: (11) 97515-8190</p>
          </div><div class="main-footer__address svelte-a66mxb"><h4 class="svelte-a66mxb">Manaus</h4>
            <p class="svelte-a66mxb">Av. Ephigênio Salles, nº 126, sala E Parque 10 de Novembro. CEP: 69.055-736 – Manaus/AM
Tel.: (92) 3648-6777 / 3648-6717</p>
          </div></div>

    <div><h4 class="svelte-a66mxb">Navigation</h4>
        <ul class="main-footer__menu svelte-a66mxb"><li class="svelte-a66mxb"><a href="/" class="--active svelte-a66mxb">Home</a>
            </li><li class="svelte-a66mxb"><a href="/platform" class=" svelte-a66mxb">Platform</a>
            </li><li class="svelte-a66mxb"><a href="/pricing" class=" svelte-a66mxb">Pricing</a>
            </li><li class="svelte-a66mxb"><a href="/security" class=" svelte-a66mxb">Security</a>
            </li><li class="svelte-a66mxb"><a href="/gallery" class=" svelte-a66mxb">Gallery</a>
            </li><li class="svelte-a66mxb"><a href="/contact" class=" svelte-a66mxb">Contact us</a>
            </li></ul></div>

    <div><h4 class="svelte-a66mxb">Privacy &amp; Security</h4>

        <div class="main-footer__quick svelte-a66mxb"><a href="/lgpd" class="svelte-a66mxb">LGPD</a><a href="/privacy-policy" class="svelte-a66mxb">Privacy Policy</a><a href="/terms-of-service" class="svelte-a66mxb">Terms of Use</a></div>

      <h4 class="svelte-a66mxb">Download the mobile App</h4>
        <div class="main-footer__download svelte-a66mxb"><a href="https://play.google.com/store/apps/details?id=br.com.sasi.app&amp;hl=pt_BR&amp;gl=US" class="store svelte-a66mxb" target="_blank" rel="noopener noreferrer"><img src="https://novo-site.sasi.com.br/api/uploads/google_play_b15b58071f.jpg" alt="Google Play" class="svelte-a66mxb">
            </a><a href="https://apps.apple.com/br/app/sasi/id1467748272" class="store svelte-a66mxb" target="_blank" rel="noopener noreferrer"><img src="https://novo-site.sasi.com.br/api/uploads/app_store_d57b823520.jpg" alt="Apple Store" class="svelte-a66mxb">
            </a></div></div></div>
  
  <div class="main-footer__credits svelte-a66mxb"><div class="container text-center"><p class="svelte-a66mxb">Copyright © | All rights reserved</p></div></div>
</footer>

  </div> 